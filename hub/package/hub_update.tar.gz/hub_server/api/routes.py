﻿"""Hub API Routes (package)."""
from fastapi import APIRouter, HTTPException, status
from datetime import datetime
from hub_server.api.contracts import (
    PublishRequest, PublishResponse,
    SearchRequest, SearchResponse, MatchResult,
    TaskCompletedRequest, TaskCompletedResponse,
    StatusUpdateRequest, StatusUpdateResponse,
)
from hub_server.services.jwt_service import jwt_service
from hub_server.services.match_service import embedding_service, MatchService
from hub_server.services.reverse_match_service import add_pending_demand, match_on_status_update

router = APIRouter()

_agent_store = {}
_task_completion_store = set()


@router.post("/publish", response_model=PublishResponse, status_code=status.HTTP_200_OK)
async def publish_agent_card(request: PublishRequest):
    try:
        description_vector = await embedding_service.get_embedding(request.description)
        is_update = request.agent_id in _agent_store

        _agent_store[request.agent_id] = {
            "agent_id": request.agent_id,
            "domain": request.domain,
            "intent_type": request.intent_type,
            "contact_endpoint": request.contact_endpoint,
            "description": request.description,
            "description_vector": description_vector,
            "tasks_requested": 0,
            "tasks_provided": 0,
            "last_active": datetime.utcnow(),
            "created_at": datetime.utcnow(),
            "node_status": "active",
            "live_broadcast": None,
            "status_updated_at": datetime.utcnow(),
        }

        return PublishResponse(
            agent_id=request.agent_id,
            status="updated" if is_update else "registered",
            registered_at=datetime.utcnow(),
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/search", response_model=SearchResponse)
async def search_collaborators(request: SearchRequest):
    try:
        query_vector = await embedding_service.get_embedding(request.query)
        matches = []

        candidates = [
            agent for agent in _agent_store.values()
            if agent.get("intent_type") == "bid" and agent.get("node_status") == "active"
        ]

        if request.domain:
            candidates = [a for a in candidates if a.get("domain") == request.domain]

        from scipy.spatial.distance import cosine
        scored = []
        for agent in candidates:
            similarity = 1 - cosine(query_vector, agent["description_vector"])
            scored.append((similarity, agent))

        scored.sort(key=lambda x: x[0], reverse=True)

        for similarity, agent in scored[:3]:
            seeker_id = "current_user"
            jwt_token = jwt_service.issue_match_token(
                seeker_id=seeker_id,
                provider_id=agent["agent_id"],
                seeker_endpoint="",
            )
            matches.append(MatchResult(
                agent_id=agent["agent_id"],
                contact_endpoint=agent["contact_endpoint"],
                match_token=jwt_token,
                tasks_provided=agent["tasks_provided"],
            ))

        return SearchResponse(matches=matches, total_searched=len(candidates))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/task_completed", response_model=TaskCompletedResponse)
async def report_task_completed(request: TaskCompletedRequest):
    try:
        payload = jwt_service.verify_match_token(request.match_token)
        seeker_id = payload["seeker"]
        provider_id = payload["provider"]

        token_hash = jwt_service.get_token_hash(request.match_token)
        if token_hash in _task_completion_store:
            raise HTTPException(status_code=400, detail="Duplicate completion")

        if seeker_id not in _agent_store or provider_id not in _agent_store:
            raise HTTPException(status_code=404, detail="Agent not found")

        _agent_store[seeker_id]["tasks_requested"] += 1
        _agent_store[provider_id]["tasks_provided"] += 1
        _task_completion_store.add(token_hash)

        return TaskCompletedResponse(
            success=True,
            message="Task completed",
            requester_tasks=_agent_store[seeker_id]["tasks_requested"],
            provider_tasks=_agent_store[provider_id]["tasks_provided"],
        )
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.patch("/status", response_model=StatusUpdateResponse, status_code=status.HTTP_200_OK)
async def update_agent_status(request: StatusUpdateRequest):
    try:
        if request.agent_id not in _agent_store:
            raise ValueError(f"Agent {request.agent_id} not found")

        match_service = MatchService(db_conn=None, embedding_service=embedding_service)
        result = await match_service.update_status(
            agent_id=request.agent_id,
            node_status=request.node_status,
            live_broadcast=request.live_broadcast,
        )

        _agent_store[request.agent_id]["node_status"] = request.node_status
        _agent_store[request.agent_id]["live_broadcast"] = request.live_broadcast

        # 触发反向撞库（向量匹配）
        new_tags = request.tags or []
        new_vector = await embedding_service.get_embedding(request.live_broadcast or "")
        matches = match_on_status_update(
            agent_id=request.agent_id,
            node_status=request.node_status,
            live_broadcast=request.live_broadcast,
            new_tags=new_tags,
            new_vector=new_vector
        )

        return StatusUpdateResponse(**result)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc))
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/pending_demands")
async def create_pending_demand(payload: dict):
    """创建悬赏需求 - 生成向量后传入 Service 层"""
    # 1. 调用 Embedding 服务生成向量
    demand_vector = await embedding_service.get_embedding(payload["description"])

    # 2. 传入 Service 层
    demand = add_pending_demand(payload, demand_vector=demand_vector)

    return {"status": "queued", "demand_id": demand.demand_id}


@router.get("/pending_demands")
async def list_demands():
    """查看所有悬赏需求"""
    from hub_server.services.reverse_match_service import list_pending_demands
    demands = list_pending_demands()
    return {
        "total": len(demands),
        "demands": [
            {
                "demand_id": d.demand_id,
                "description": d.description,
                "tags": d.tags,
                "status": d.status,
                "matched_agent_id": d.matched_agent_id
            }
            for d in demands
        ]
    }
