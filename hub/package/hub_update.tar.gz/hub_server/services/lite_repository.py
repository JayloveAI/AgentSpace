"""
SQLite + NumPy 极简存储实现
替代 PostgreSQL + pgvector，用于 MVP 验证
"""
import sqlite3
import numpy as np
import json
from typing import List, Optional
from dataclasses import dataclass
from datetime import datetime


@dataclass
class PendingDemand:
    demand_id: str
    resource_type: str
    description: str
    tags: List[str]
    demand_vector: List[float]  # 👈 必须要有向量字段
    seeker_id: Optional[str]
    created_at: str
    status: str = "pending"
    matched_agent_id: Optional[str] = None


class LiteMemoryRepository:
    """SQLite + NumPy 极简存储"""

    def __init__(self, db_path: str = "hub_mvp.db"):
        self.db_path = db_path
        self._init_db()

    def _init_db(self):
        """初始化数据库表"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS pending_demands (
                    demand_id TEXT PRIMARY KEY,
                    resource_type TEXT,
                    description TEXT,
                    tags TEXT,
                    demand_vector TEXT,  -- 👈 存 JSON 格式的浮点数数组
                    seeker_id TEXT,
                    created_at TEXT,
                    status TEXT DEFAULT 'pending',
                    matched_agent_id TEXT
                )
            """)

    def add_demand(self, demand: PendingDemand) -> PendingDemand:
        """添加悬赏需求"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT OR REPLACE INTO pending_demands
                (demand_id, resource_type, description, tags, demand_vector, seeker_id, created_at, status, matched_agent_id)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                demand.demand_id,
                demand.resource_type,
                demand.description,
                json.dumps(demand.tags),
                json.dumps(demand.demand_vector),  # 👈 向量转 JSON 存入
                demand.seeker_id,
                demand.created_at,
                demand.status,
                demand.matched_agent_id
            ))
        return demand

    def _cosine_similarity(self, vec_a: List[float], vec_b: List[float]) -> float:
        """真正的 NumPy 极速余弦相似度计算"""
        a, b = np.array(vec_a), np.array(vec_b)
        if np.linalg.norm(a) == 0 or np.linalg.norm(b) == 0:
            return 0.0
        return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b)))

    def find_matches(self, new_tags: List[str], new_vector: List[float], threshold: float = 0.7) -> List[PendingDemand]:
        """标签初筛 + NumPy 向量精筛"""
        matches = []
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT * FROM pending_demands WHERE status = 'pending'")
            for row in cursor.fetchall():
                demand = PendingDemand(
                    demand_id=row[0],
                    resource_type=row[1],
                    description=row[2],
                    tags=json.loads(row[3]),
                    demand_vector=json.loads(row[4]),
                    seeker_id=row[5],
                    created_at=row[6],
                    status=row[7],
                    matched_agent_id=row[8]
                )

                # 1. 标签交集初筛 (加速)
                if not set(new_tags).intersection(set(demand.tags)):
                    continue

                # 2. NumPy 向量计算相似度
                sim = self._cosine_similarity(demand.demand_vector, new_vector)
                if sim >= threshold:
                    matches.append((demand, sim))

        # 按相似度降序排序并返回
        matches.sort(key=lambda x: x[1], reverse=True)
        return [m[0] for m in matches]

    def mark_matched(self, demand_id: str, agent_id: str):
        """标记为已匹配"""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute(
                "UPDATE pending_demands SET status = 'matched', matched_agent_id = ? WHERE demand_id = ?",
                (agent_id, demand_id)
            )

    def get_all_pending(self) -> List[PendingDemand]:
        """获取所有待处理需求"""
        with sqlite3.connect(self.db_path) as conn:
            cursor = conn.execute("SELECT * FROM pending_demands WHERE status = 'pending'")
            demands = []
            for row in cursor.fetchall():
                demands.append(PendingDemand(
                    demand_id=row[0],
                    resource_type=row[1],
                    description=row[2],
                    tags=json.loads(row[3]),
                    demand_vector=json.loads(row[4]),
                    seeker_id=row[5],
                    created_at=row[6],
                    status=row[7],
                    matched_agent_id=row[8]
                ))
            return demands


# 单例实例
_repo = LiteMemoryRepository()


def get_repository() -> LiteMemoryRepository:
    return _repo
