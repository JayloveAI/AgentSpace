"""
Acceptance Tests - 门票防伪与拦截测试 (用例 5-6)
================================================
验证 JWT 安全机制
"""
import pytest
import jwt
from client_sdk.config import HUB_JWT_SECRET


@pytest.mark.asyncio
@pytest.mark.acceptance
async def test_missing_token_returns_403(webhook_server):
    """
    用例 5: 缺少 JWT 门票返回 403
    - 构造无 X-Match-Token 头的恶意 POST 请求
    - 必须立刻被 FastAPI 拦截并返回 HTTP 403
    """
    response = await webhook_server.post("/api/webhook", json={
        "sender_id": "malicious_agent",
        "task_type": "attack",
        "task_context": {}
    })
    
    assert response.status_code == 403
    data = response.json()
    assert "error" in data
    assert data["error"] == "MissingTokenError"


@pytest.mark.asyncio
@pytest.mark.acceptance
async def test_tampered_token_rejected(webhook_server):
    """
    用例 6a: 篡改 JWT 被拦截
    - 修改 JWT Payload 中的 seeker 字段
    - 本地 Agent 解码必须失败并阻断请求
    """
    # 创建原始 token
    original_token = jwt.encode(
        {"seeker": "agent_a", "provider": "agent_b", "type": "match_ticket"},
        HUB_JWT_SECRET,
        algorithm="HS256"
    )
    
    # 篡改 token (修改 payload)
    decoded = jwt.decode(original_token, options={"verify_signature": False})
    decoded["seeker"] = "malicious_agent"
    tampered_token = jwt.encode(decoded, "wrong_secret", algorithm="HS256")
    
    # 发送请求
    response = await webhook_server.post(
        "/api/webhook",
        json={"sender_id": "agent_a", "task_type": "test", "task_context": {}},
        headers={"X-Match-Token": tampered_token}
    )
    
    assert response.status_code == 403
    data = response.json()
    assert "error" in data


@pytest.mark.asyncio
@pytest.mark.acceptance
async def test_expired_token_rejected(webhook_server):
    """
    用例 6b: 过期 JWT 被拦截
    - 使用过期超过 10 分钟的门票
    - 本地 Agent 解码必须失败并阻断请求
    """
    import datetime
    
    # 创建过期 token
    expired_token = jwt.encode(
        {
            "seeker": "agent_a",
            "provider": "agent_b",
            "type": "match_ticket",
            "exp": datetime.datetime.utcnow() - datetime.timedelta(minutes=15)  # 15分钟前过期
        },
        HUB_JWT_SECRET,
        algorithm="HS256"
    )
    
    # 发送请求
    response = await webhook_server.post(
        "/api/webhook",
        json={"sender_id": "agent_a", "task_type": "test", "task_context": {}},
        headers={"X-Match-Token": expired_token}
    )
    
    assert response.status_code == 403
    data = response.json()
    assert "error" in data or "TokenExpiredError" in str(data)
