"""
Acceptance Tests - 混合检索测试 (用例 3-4)
===========================================
验证向量检索性能和返回数据完整性
"""
import pytest
import httpx


@pytest.mark.asyncio
@pytest.mark.acceptance
async def test_hybrid_search_performance(mock_hub_server, sample_agents):
    """
    用例 3: 混合检索性能测试
    - 构造 100 个模拟节点
    - 使用 domain 字段进行 WHERE 过滤
    - 检索耗时控制在 200ms 以内
    """
    import time
    
    # 创建 100 个模拟 Agent
    for i in range(100):
        await mock_hub_server.post("/api/v1/publish", json={
            "agent_id": f"agent_{i}",
            "domain": "finance" if i % 2 == 0 else "education",
            "intent_type": "bid",
            "contact_endpoint": f"https://agent{i}.ngrok.app/api/webhook",
            "description": f"Agent {i} 专注数据处理"
        })
    
    # 发起搜索
    start_time = time.time()
    response = await mock_hub_server.post("/api/v1/search", json={
        "query": "需要处理金融数据回测",
        "domain": "finance"
    })
    elapsed_ms = (time.time() - start_time) * 1000
    
    # 验证
    assert response.status_code == 200
    data = response.json()
    assert "matches" in data
    assert "total_searched" in data
    
    # 性能要求: 200ms 以内
    assert elapsed_ms < 200, f"检索耗时 {elapsed_ms}ms 超过 200ms 限制"
    
    # 验证 domain 过滤生效
    assert data["total_searched"] == 50  # 100 个中 50 个是 finance


@pytest.mark.asyncio
@pytest.mark.acceptance
async def test_search_response_includes_tasks_provided(mock_hub_server):
    """
    用例 4: 搜索结果包含 tasks_provided
    - 返回的 Top 3 名单必须正确挂载 tasks_provided 数据
    """
    # 注册不同贡献度的 Agent
    agents_data = [
        ("agent_high", 342),
        ("agent_medium", 15),
        ("agent_low", 0)
    ]
    
    for agent_id, tasks_provided in agents_data:
        # 先注册
        await mock_hub_server.post("/api/v1/publish", json={
            "agent_id": agent_id,
            "domain": "education",
            "intent_type": "bid",
            "contact_endpoint": f"https://{agent_id}.ngrok.app/api/webhook",
            "description": "教育数据处理专家"
        })
    
    # 搜索
    response = await mock_hub_server.post("/api/v1/search", json={
        "query": "需要教育数据处理",
        "domain": "education"
    })
    
    assert response.status_code == 200
    data = response.json()
    matches = data["matches"]
    
    # 验证每个匹配结果都包含 tasks_provided
    for match in matches:
        assert "tasks_provided" in match
        assert isinstance(match["tasks_provided"], int)
        assert match["tasks_provided"] >= 0
