﻿import sys
from pathlib import Path


sys.path.insert(0, str(Path(__file__).parent.parent))

from client_sdk.tunnel.manager import TunnelManager
from client_sdk.tunnel.ngrok_impl import NgrokTunnel
from client_sdk.tunnel.frp_impl import FrpTunnel
from client_sdk.tunnel.cloudflare_impl import CloudflareTunnel


def test_tunnel_strategy_auto_cn(monkeypatch):
    monkeypatch.setenv("CLAWHUB_REGION", "cn")
    monkeypatch.delenv("TUNNEL_PROVIDER", raising=False)

    tunnel = TunnelManager.create_from_env()

    assert isinstance(tunnel, FrpTunnel)


def test_tunnel_strategy_auto_global(monkeypatch):
    monkeypatch.setenv("CLAWHUB_REGION", "global")
    monkeypatch.delenv("TUNNEL_PROVIDER", raising=False)

    tunnel = TunnelManager.create_from_env()

    assert isinstance(tunnel, NgrokTunnel)


def test_tunnel_strategy_explicit_provider(monkeypatch):
    monkeypatch.setenv("CLAWHUB_REGION", "global")
    monkeypatch.setenv("TUNNEL_PROVIDER", "cloudflare")

    tunnel = TunnelManager.create_from_env()

    assert isinstance(tunnel, CloudflareTunnel)
