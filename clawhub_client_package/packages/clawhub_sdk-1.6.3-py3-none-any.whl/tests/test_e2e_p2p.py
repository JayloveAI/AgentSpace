"""
跨设备 P2P 端到端测试
======================

此脚本用于测试完整的 Seeker-Provider 协同流程。

使用方法:
---------

方案 A: 单机模拟模式（用于快速验证）
    python tests/test_e2e_p2p.py --mode simulate

方案 B: 双设备真实模式（需要两个终端）

终端 1 (Seeker 设备):
    python tests/test_e2e_p2p.py --role seeker --port 8000

终端 2 (Provider 设备):
    python tests/test_e2e_p2p.py --role provider --seeker-url https://abc123.ngrok.app
"""

import argparse
import asyncio
import json
import os
import sys
import tempfile
from pathlib import Path
from datetime import datetime

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from client_sdk.tunnel.manager import TunnelManager
from client_sdk.webhook.server import WebhookServer
from client_sdk.webhook.sender import P2PSender
from client_sdk.gateway.router import UniversalResourceGateway


class E2EP2PTester:
    """端到端 P2P 测试器"""

    def __init__(self, role: str, port: int = 8000):
        self.role = role
        self.port = port
        self.test_results = []

    def log(self, message: str, level: str = "INFO"):
        """日志输出"""
        prefix = {
            "INFO": "[INFO]",
            "OK": "[OK]  ",
            "WARN": "[WARN]",
            "ERROR": "[ERR] ",
        }
        print(f"{prefix.get(level, '[----]')} {message}")
        if level != "INFO":
            self.test_results.append((level, message))

    async def run_seeker(self, use_tunnel: bool = True):
        """
        运行 Seeker 端（需求方）

        流程:
        1. 启动 Ngrok 隧道（可选）
        2. 启动 Webhook 服务器
        3. 发布需求到 Hub
        4. 等待文件投递
        """
        self.log("=" * 50, "INFO")
        self.log("Seeker 端启动 (需求方)", "INFO")
        self.log("=" * 50, "INFO")

        # 1. 启动隧道（如果配置了 Token）
        public_url = None
        if use_tunnel and os.getenv("NGROK_AUTHTOKEN"):
            self.log("\n[步骤 1] 启动 Ngrok 隧道...", "INFO")
            try:
                tunnel = TunnelManager(port=self.port)
                public_url = await tunnel.start()
                self.log(f"公网 URL: {public_url}", "OK")
            except Exception as e:
                self.log(f"隧道启动失败: {e}", "WARN")
                self.log("使用 localhost 模式", "WARN")
                public_url = f"http://localhost:{self.port}"
        else:
            if not os.getenv("NGROK_AUTHTOKEN"):
                self.log("未配置 NGROK_AUTHTOKEN，使用本地模式", "WARN")
            public_url = f"http://localhost:{self.port}"

        # 2. 启动 Webhook 服务器
        self.log(f"\n[步骤 2] 启动 Webhook 服务器 (端口 {self.port})...", "INFO")

        delivery_file = None

        def task_handler(task_type: str, context: dict):
            """本地任务处理器"""
            self.log(f"收到任务: {task_type}", "INFO")

        # 创建全局事件用于通知
        delivery_received = asyncio.Event()

        # 保存到文件的全局变量
        class DeliveryState:
            file_path = None

        delivery_state = DeliveryState()

        # 创建 mock gateway 用于触发事件
        def make_trigger_delivery(tester, state):
            def trigger_delivery(demand_id: str, file_path: str):
                tester.log(f"\n[!] 收到文件投递: {file_path}", "OK")
                state.file_path = file_path
                delivery_received.set()
            return trigger_delivery

        class MockGateway:
            def __init__(self, trigger_fn):
                self.trigger_delivery = trigger_fn

        # 设置全局 gateway 实例
        from client_sdk.webhook import server as webhook_server_module
        mock_gateway = MockGateway(make_trigger_delivery(self, delivery_state))
        webhook_server_module.set_gateway_instance(mock_gateway)

        webhook_server = WebhookServer(port=self.port, task_handler=task_handler)

        # 在后台运行 Webhook 服务器
        server_task = asyncio.create_task(webhook_server.run_async())

        self.log("Webhook 服务器已启动", "OK")
        self.log(f"收货地址: {public_url}/api/webhook/delivery", "INFO")

        # 3. 发布需求（模拟）
        self.log("\n[步骤 3] 发布测试需求...", "INFO")

        test_demand_id = f"test-demand-{datetime.now().strftime('%Y%m%d%H%M%S')}"

        # 创建测试文件内容
        test_content = {
            "demand_id": test_demand_id,
            "resource_type": "csv",
            "description": "销售数据报表",
            "tags": ["data", "sales", "csv"],
            "seeker_webhook_url": f"{public_url}/api/webhook/delivery",
            "created_at": datetime.utcnow().isoformat(),
        }

        self.log(f"需求 ID: {test_demand_id}", "INFO")
        self.log(f"收货地址: {test_content['seeker_webhook_url']}", "INFO")

        # 保存需求信息到文件（供 Provider 读取）
        demand_file = Path(tempfile.gettempdir()) / f"demand_{test_demand_id}.json"
        demand_file.write_text(json.dumps(test_content, indent=2), encoding="utf-8")
        self.log(f"需求已保存到: {demand_file}", "INFO")

        # 4. 等待文件投递
        self.log(f"\n[步骤 4] 等待 Provider 投递文件...", "INFO")
        self.log("提示: 在另一个终端运行 Provider 端", "WARN")

        try:
            # 等待 5 分钟
            await asyncio.wait_for(delivery_received.wait(), timeout=300)

            self.log("\n[OK] 文件投递成功！", "OK")
            self.log(f"文件路径: {delivery_state.file_path}", "INFO")

            # 验证文件
            if delivery_state.file_path and Path(delivery_state.file_path).exists():
                file_size = Path(delivery_state.file_path).stat().st_size
                self.log(f"文件大小: {file_size} bytes", "INFO")

                with open(delivery_state.file_path, "r", encoding="utf-8") as f:
                    content = f.read()
                    self.log(f"文件内容预览:\n{content[:200]}...", "INFO")

        except asyncio.TimeoutError:
            self.log("\n[TIMEOUT] 5 分钟内未收到文件投递", "WARN")
        finally:
            # 清理
            server_task.cancel()
            try:
                await server_task
            except asyncio.CancelledError:
                pass

    async def run_provider(self, seeker_url: str):
        """
        运行 Provider 端（提供方）

        流程:
        1. 读取 Seeker 的需求信息
        2. 生成测试文件
        3. 直接向 Seeker 的公网地址投递文件
        """
        self.log("=" * 50, "INFO")
        self.log("Provider 端启动 (提供方)", "INFO")
        self.log("=" * 50, "INFO")

        # 1. 查找最新的需求文件
        self.log("\n[步骤 1] 查找 Seeker 需求...", "INFO")

        temp_dir = Path(tempfile.gettempdir())
        demand_files = list(temp_dir.glob("demand_*.json"))

        if not demand_files:
            self.log("未找到需求文件！", "ERROR")
            self.log("请先运行 Seeker 端", "WARN")
            return

        # 使用最新的需求文件
        latest_demand_file = max(demand_files, key=lambda p: p.stat().st_mtime)
        self.log(f"找到需求文件: {latest_demand_file.name}", "OK")

        demand_data = json.loads(latest_demand_file.read_text(encoding="utf-8"))

        # 2. 生成测试文件
        self.log("\n[步骤 2] 生成测试文件...", "INFO")

        test_file = temp_dir / f"test_output_{datetime.now().strftime('%Y%m%d%H%M%S')}.csv"
        test_content = """date,product,sales,region
2024-01-01,Product A,1250,North
2024-01-01,Product B,980,South
2024-01-02,Product A,1100,North
2024-01-02,Product C,750,East
2024-01-03,Product B,1300,South"""

        test_file.write_text(test_content, encoding="utf-8")
        self.log(f"测试文件已创建: {test_file}", "OK")

        # 3. 投递文件
        self.log("\n[步骤 3] 向 Seeker 投递文件...", "INFO")

        # 如果指定了 seeker_url，使用它覆盖需求中的 URL
        if seeker_url:
            # 确保 URL 包含 /api/webhook/delivery 路径
            if not seeker_url.endswith("/api/webhook/delivery"):
                seeker_url = f"{seeker_url.rstrip('/')}/api/webhook/delivery"
            demand_data["seeker_webhook_url"] = seeker_url

        self.log(f"目标地址: {demand_data['seeker_webhook_url']}", "INFO")
        self.log(f"需求 ID: {demand_data['demand_id']}", "INFO")

        sender = P2PSender()

        success = await sender.send_file_to_seeker(
            matched_demand=demand_data,
            file_path=str(test_file),
            provider_id="test-provider-001"
        )

        if success:
            self.log("\n[OK] 文件投递成功！", "OK")
            self.log("请检查 Seeker 端是否收到文件", "INFO")
        else:
            self.log("\n[ERROR] 文件投递失败", "ERROR")

    async def run_simulation(self):
        """
        运行模拟模式（单机测试）

        模拟完整的 Seeker-Provider 流程，无需真实隧道
        """
        self.log("=" * 50, "INFO")
        self.log("模拟模式: 单机端到端测试", "INFO")
        self.log("=" * 50, "INFO")

        # 使用本地地址
        local_url = f"http://localhost:{self.port}"

        # 1. 启动 Webhook 服务器
        self.log("\n[步骤 1] 启动 Webhook 服务器...", "INFO")

        server_started = asyncio.Event()

        def task_handler(task_type: str, context: dict):
            self.log(f"收到任务: {task_type}", "INFO")

        class DeliveryState:
            file_path = None

        delivery_state = DeliveryState()
        delivery_received = asyncio.Event()

        # 创建 mock gateway 用于触发事件
        # 使用闭包捕获 self 和 delivery_state
        def make_trigger_delivery(tester, state):
            def trigger_delivery(demand_id: str, file_path: str):
                tester.log(f"\n[!] 收到文件投递: {file_path}", "OK")
                state.file_path = file_path
                delivery_received.set()
            return trigger_delivery

        class MockGateway:
            def __init__(self, trigger_fn):
                self.trigger_delivery = trigger_fn

        # 设置全局 gateway 实例
        from client_sdk.webhook import server as webhook_server_module
        mock_gateway = MockGateway(make_trigger_delivery(self, delivery_state))
        webhook_server_module.set_gateway_instance(mock_gateway)

        webhook_server = WebhookServer(port=self.port, task_handler=task_handler)
        server_task = asyncio.create_task(webhook_server.run_async())
        await asyncio.sleep(1)  # 等待服务器启动

        self.log("Webhook 服务器已启动", "OK")

        # 2. 模拟需求发布
        self.log("\n[步骤 2] 模拟需求发布...", "INFO")

        test_demand_id = f"sim-demand-{datetime.now().strftime('%Y%m%d%H%M%S')}"

        demand_data = {
            "demand_id": test_demand_id,
            "resource_type": "csv",
            "description": "模拟测试需求",
            "tags": ["data", "test"],
            "seeker_webhook_url": f"{local_url}/api/webhook/delivery",
        }

        self.log(f"需求 ID: {test_demand_id}", "INFO")
        self.log(f"收货地址: {demand_data['seeker_webhook_url']}", "INFO")

        # 3. 模拟 Provider 投递文件
        self.log("\n[步骤 3] 模拟 Provider 投递文件...", "INFO")

        # 创建测试文件
        test_file = Path(tempfile.gettempdir()) / f"sim_test.csv"
        test_content = "col1,col2,col3\n1,2,3\n4,5,6"
        test_file.write_text(test_content, encoding="utf-8")

        sender = P2PSender()

        success = await sender.send_file_to_seeker(
            matched_demand=demand_data,
            file_path=str(test_file),
            provider_id="sim-provider"
        )

        if not success:
            self.log("文件投递失败！", "ERROR")
            server_task.cancel()
            return

        # 4. 等待接收
        self.log("\n[步骤 4] 等待接收文件...", "INFO")

        try:
            await asyncio.wait_for(delivery_received.wait(), timeout=10)

            self.log("\n[OK] 模拟测试成功！", "OK")
            self.log(f"文件已投递到: {delivery_state.file_path}", "INFO")

            # 验证内容
            if delivery_state.file_path and Path(delivery_state.file_path).exists():
                with open(delivery_state.file_path, "r", encoding="utf-8") as f:
                    content = f.read()
                    self.log(f"文件内容: {content}", "INFO")

        except asyncio.TimeoutError:
            self.log("[TIMEOUT] 未收到文件", "ERROR")
        finally:
            server_task.cancel()

    def print_summary(self):
        """打印测试总结"""
        self.log("\n" + "=" * 50, "INFO")
        self.log("[测试总结]", "INFO")

        passed = sum(1 for r in self.test_results if r[0] == "OK")
        failed = sum(1 for r in self.test_results if r[0] == "ERR")
        warnings = sum(1 for r in self.test_results if r[0] == "WARN")

        self.log(f"通过: {passed}", "OK" if passed > 0 else "INFO")
        self.log(f"失败: {failed}", "ERROR" if failed > 0 else "INFO")
        self.log(f"警告: {warnings}", "WARN" if warnings > 0 else "INFO")


async def main():
    """主入口"""
    parser = argparse.ArgumentParser(description="跨设备 P2P 端到端测试")
    parser.add_argument(
        "--mode",
        choices=["seeker", "provider", "simulate"],
        default="simulate",
        help="运行模式: seeker(需求方), provider(提供方), simulate(模拟)"
    )
    parser.add_argument("--port", type=int, default=8000, help="Webhook 服务器端口")
    parser.add_argument("--seeker-url", type=str, help="Seeker 的公网 URL (Provider 模式使用)")
    parser.add_argument("--use-tunnel", action="store_true", help="是否启动 Ngrok 隧道")

    args = parser.parse_args()

    tester = E2EP2PTester(role=args.mode, port=args.port)

    try:
        if args.mode == "seeker":
            await tester.run_seeker(use_tunnel=args.use_tunnel)
        elif args.mode == "provider":
            if not args.seeker_url:
                print("[ERROR] Provider 模式需要 --seeker-url 参数")
                print("示例: python tests/test_e2e_p2p.py --role provider --seeker-url https://abc123.ngrok.app")
                return
            await tester.run_provider(args.seeker_url)
        else:  # simulate
            await tester.run_simulation()

        tester.print_summary()

    except KeyboardInterrupt:
        print("\n[INFO] 测试已中断")
    except Exception as e:
        print(f"[ERROR] 测试失败: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
