"""
ClawHub V1.5 部署包生成器
========================

生成包含所有依赖的离线部署包，可复制到目标电脑直接安装。
"""

import os
import shutil
import subprocess
from pathlib import Path


def create_deploy_package(output_dir: Path = None):
    """
    创建 ClawHub 离线部署包

    Args:
        output_dir: 输出目录，默认为 e:/hub_deploy
    """
    if output_dir is None:
        output_dir = Path("e:/hub_deploy")
    else:
        output_dir = Path(output_dir)

    # 创建部署目录
    output_dir.mkdir(parents=True, exist_ok=True)
    dist_dir = output_dir / "packages"
    dist_dir.mkdir(exist_ok=True)

    print(f"[1/5] 创建部署目录: {output_dir}")

    # 复制 Wheel 包
    hub_dist = Path("e:/hub/dist")
    wheel_file = hub_dist / "clawhub_sdk-1.5.0-py3-none-any.whl"

    if wheel_file.exists():
        shutil.copy(wheel_file, dist_dir / wheel_file.name)
        print(f"[2/5] 复制 SDK Wheel 包: {wheel_file.name}")
    else:
        print(f"[2/5] WARNING Wheel 包不存在，请先运行: python setup.py bdist_wheel")
        return False

    # 下载所有依赖（使用国内镜像源）
    print(f"[3/5] 下载依赖包（使用清华镜像源）...")
    try:
        # 使用本地 Wheel 包解析并下载所有依赖
        subprocess.run([
            "pip", "download",
            "-d", str(dist_dir),
            "-i", "https://pypi.tuna.tsinghua.edu.cn/simple",
            "--trusted-host", "pypi.tuna.tsinghua.edu.cn",
            "--only-binary", ":all:",
            str(wheel_file)
        ], check=True, capture_output=True)

        print(f"   OK 依赖下载完成")
    except subprocess.CalledProcessError as e:
        # 如果本地 Wheel 下载失败，尝试直接指定依赖列表
        print(f"   INFO 尝试直接下载依赖...")
        deps = [
            "httpx>=0.24.0", "pydantic>=2.0.0", "fastapi>=0.100.0",
            "uvicorn>=0.23.0", "python-dotenv>=1.0.0", "pyngrok>=7.0.0",
            "python-multipart>=0.0.6", "watchdog>=3.0.0", "pyyaml>=6.0",
            "rich>=13.0.0", "questionary>=2.0.0"
        ]
        subprocess.run([
            "pip", "download",
            "-d", str(dist_dir),
            "-i", "https://pypi.tuna.tsinghua.edu.cn/simple",
            "--trusted-host", "pypi.tuna.tsinghua.edu.cn",
        ] + deps, check=False)

        print(f"   OK 依赖下载完成")

    # 创建安装脚本
    install_script = f"""@echo off
chcp 65001 >nul
echo ============================================
echo   ClawHub V1.5 离线安装
echo ============================================
echo.

echo [1/3] 安装 ClawHub SDK...
pip install --no-index --find-links=packages clawhub-sdk

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [X] 安装失败！
    echo 请检查：
    echo   1. Python 3.8+ 已安装
    echo   2. 所有文件都已复制到此目录
    pause
    exit /b 1
)

echo.
echo [2/3] 验证安装...
python -c "import client_sdk" 2>nul
if %ERRORLEVEL% NEQ 0 (
    echo [!] 模块导入验证失败，但已安装
) else (
    echo [OK] 模块导入验证通过
)

echo.
echo [3/3] 安装完成！
echo.
echo ============================================
echo   启动命令:
echo     clawhub start
echo ============================================
echo.
echo 提示: 如遇编码问题，使用以下命令启动:
echo   set PYTHONIOENCODING=utf-8 && clawhub start
echo.

pause
"""

    install_bat = output_dir / "install.bat"
    install_bat.write_text(install_script, encoding="gbk")
    print(f"[4/5] 创建安装脚本: {install_bat}")

    # 创建 README
    readme_content = """ClawHub V1.5 离线部署包
========================

快速安装：
1. 双击运行 install.bat
2. 等待安装完成
3. 运行: clawhub start

目录说明：
- packages/     : 所有依赖包
- install.bat   : 自动安装脚本
- README.txt    : 本文件

系统要求：
- Python 3.8+
- Windows 10/11

工作目录安装后：~/.clawhub/
  - demand_inbox/      : 接收文件
  - supply_provided/   : 共享文件

启动命令：
  clawhub start      : 启动节点
  clawhub status     : 查看状态

如遇编码问题：
  set PYTHONIOENCODING=utf-8 && clawhub start

模块说明：
  包名: clawhub-sdk (pip install 用)
  模块: client_sdk (Python import 用)

文档：
  https://github.com/openclaw/clawhub
"""

    readme_file = output_dir / "README.txt"
    readme_file.write_text(readme_content, encoding="utf-8")
    print(f"[5/5] 创建说明文档: {readme_file}")

    # 统计信息
    package_count = len(list(dist_dir.glob("*.whl"))) + len(list(dist_dir.glob("*.tar.gz")))
    total_size = sum(f.stat().st_size for f in dist_dir.rglob("*"))

    print(f"\n[OK] 部署包创建完成！")
    print(f"\n[*] 部署包位置: {output_dir}")
    print(f"[*] 包含文件: {package_count} 个")
    print(f"[*] 总大小: {total_size / 1024 / 1024:.1f} MB")
    print(f"\n[*] 部署方式：")
    print(f"   1. 将整个 '{output_dir.name}' 文件夹复制到目标电脑")
    print(f"   2. 双击运行 install.bat")
    print(f"   3. 启动: clawhub start")

    return True


def create_portable_installer():
    """创建单文件便携式安装包"""
    print("\n创建便携式安装包...")

    # 创建 PowerShell 版本的安装脚本
    ps_script = f"""
# ClawHub V1.5 便携式安装
Write-Host "============================================"
Write-Host "  ClawHub V1.5 离线安装"
Write-Host "============================================"
Write-Host ""

# 设置当前脚本所在目录为工作目录
$ScriptPath = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $ScriptPath

Write-Host "[1/3] 安装 ClawHub SDK..."
$env:PYTHONIOENCODING = "utf-8"

try {{
    pip install --no-index --find-links=packages clawhub-sdk
    Write-Host "   [OK] 安装成功" -ForegroundColor Green
}} catch {{
    Write-Host "   [X] 安装失败: $_" -ForegroundColor Red
    Write-Host ""
    Write-Host "请检查：" -ForegroundColor Yellow
    Write-Host "  1. Python 3.8+ 已安装" -ForegroundColor White
    Write-Host "  2. packages 文件夹存在" -ForegroundColor White
    Write-Host "  3. 所有依赖文件都已复制" -ForegroundColor White
    Read-Host "按回车键退出"
    exit 1
}}

Write-Host ""
Write-Host "[2/3] 验证安装..."
try {{
    python -c "import client_sdk"
    Write-Host "   [OK] 模块导入验证通过" -ForegroundColor Green
}} catch {{
    Write-Host "   [!] 模块导入验证失败" -ForegroundColor Yellow
}}

Write-Host ""
Write-Host "[3/3] 安装完成！" -ForegroundColor Green
Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  启动命令:" -ForegroundColor White
Write-Host "    clawhub start" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""

# 询问是否立即启动
$response = Read-Host "是否立即启动 ClawHub？(Y/N)"
if ($response -eq 'Y' -or $response -eq 'y') {{
    clawhub start
}}
"""

    ps_file = Path("e:/hub_deploy/install.ps1")
    ps_file.write_text(ps_script, encoding="utf-8")

    print(f"   [OK] PowerShell 安装脚本: {ps_file}")
    print(f"\n使用方式：复制整个文件夹后，右键 install.ps1 → 以管理员身份运行")


if __name__ == "__main__":
    import sys

    print("============================================")
    print("  ClawHub V1.5 部署包生成器")
    print("============================================")
    print()

    # 生成部署包
    success = create_deploy_package()

    if success:
        # 生成便携式安装脚本
        create_portable_installer()

        print(f"\n[OK] 部署包已准备就绪！")
        print(f"\n[*] 将 'e:\\hub_deploy' 文件夹复制到目标电脑即可")
        print(f"[*] 然后双击运行 install.bat 进行安装")
