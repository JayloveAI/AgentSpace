"""
AgentHub V1.5 End-to-End Test
================================
测试两个 Agent 之间的完整交互流程：

Agent A (需求方) → Hub → Agent B (服务方)
    ↓                    ↓
  Search              Register
    ↓                    ↓
P2P Task Request ← Webhook Server
    ↓
P2P Task Response
"""
import asyncio
import sys
from pathlib import Path

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from client_sdk.daemon.gateway import LocalGatewayDaemon
from rich.console import Console

console = Console()


# ============================================================================
# Agent B: 文本清洗服务提供方
# ============================================================================

class TextCleaningAgent:
    """
    Agent B: 专门清洗文本的 Agent

    【提供能力】：文本清洗、格式化、去重
    【寻求合作】：需要高质量数据源
    """

    AGENT_ID = "text_cleaning_bot"
    HUB_URL = "http://localhost:8000"

    def __init__(self):
        self.daemon = LocalGatewayDaemon(
            agent_id=self.AGENT_ID,
            hub_url=self.HUB_URL,
            local_port=8001,  # Different port
            identity_path="tests/fixtures/identity_agent_b.md"
        )
        self.received_tasks = []

    async def task_handler(self, task_type: str, task_context: dict):
        """
        处理传入的任务

        任务类型：
        - clean_text: 清洗文本
        - format_markdown: 格式化为 Markdown
        - remove_duplicates: 去重
        """
        console.print(f"\n[green]📨 Received Task:[/green] {task_type}")
        console.print(f"[dim]Context:[/dim] {task_context}")

        # 记录任务
        task_record = {
            "task_type": task_type,
            "context": task_context,
            "received_at": asyncio.get_event_loop().time()
        }
        self.received_tasks.append(task_record)

        # 处理任务
        result = await self._process_task(task_type, task_context)

        console.print(f"[green]✅ Task Completed:[/green] {result}")
        return result

    async def _process_task(self, task_type: str, context: dict):
        """实际任务处理逻辑"""
        await asyncio.sleep(0.5)  # 模拟处理时间

        if task_type == "clean_text":
            raw_text = context.get("text", "")
            # 简单处理：去除多余空格
            cleaned = " ".join(raw_text.split())
            return {
                "status": "success",
                "original_length": len(raw_text),
                "cleaned_length": len(cleaned),
                "cleaned_text": cleaned[:100] + "..." if len(cleaned) > 100 else cleaned
            }

        elif task_type == "format_markdown":
            return {
                "status": "success",
                "formatted": "# Formatted Content\n\n" + context.get("text", "")[:100]
            }

        else:
            return {
                "status": "error",
                "message": f"Unknown task type: {task_type}"
            }

    async def start(self):
        """启动 Agent B（Code API 模式）"""
        console.print(f"\n[bold cyan]Starting Agent B: {self.AGENT_ID}[/bold cyan]")
        console.print("[dim]Mode: Code API (Service Provider)[/dim]\n")

        await self.daemon.code_api_mode(
            task_callback=self.task_handler
        )

    async def update_status(self, status: str, broadcast: str):
        """更新状态"""
        return await self.daemon.update_status(
            node_status=status,
            live_broadcast=broadcast
        )


# ============================================================================
# Agent A: 数据分析需求方
# ============================================================================

class DataAnalysisAgent:
    """
    Agent A: 数据分析 Agent

    【提供能力】：数据分析、可视化
    【寻求合作】：需要数据清洗服务
    """

    AGENT_ID = "data_analysis_bot"
    HUB_URL = "http://localhost:8000"

    def __init__(self):
        self.daemon = LocalGatewayDaemon(
            agent_id=self.AGENT_ID,
            hub_url=self.HUB_URL,
            local_port=8002,
            identity_path="tests/fixtures/identity_agent_a.md"
        )

    async def start(self):
        """启动 Agent A（Interactive CLI 模式）"""
        console.print(f"\n[bold cyan]Starting Agent A: {self.AGENT_ID}[/bold cyan]")
        console.print("[dim]Mode: Interactive CLI (Requester)[/dim]\n")

        # 先启动基础服务
        await self.daemon._initialize_and_connect()

        # 展示菜单
        await self._show_menu()

    async def _show_menu(self):
        """显示交互菜单"""
        from rich.panel import Panel
        from rich.table import Table

        while True:
            menu_table = Table(title="[bold blue]Agent A - Data Analysis Bot[/bold blue]")
            menu_table.add_column("Option", style="cyan")
            menu_table.add_column("Description", style="white")
            menu_table.add_row("1", "Search for text cleaning agents")
            menu_table.add_row("2", "Send test task to Agent B")
            menu_table.add_row("3", "Check Agent B status")
            menu_table.add_row("4", "Update own status")
            menu_table.add_row("0", "Exit")

            console.print(menu_table)

            try:
                choice = await console.input("\n[bold cyan]Select option:[/bold cyan] ")
                choice = choice.strip()

                if choice == "0":
                    console.print("[yellow]Shutting down...[/yellow]")
                    break
                elif choice == "1":
                    await self._search_agents()
                elif choice == "2":
                    await self._send_test_task()
                elif choice == "3":
                    await self._check_agent_status()
                elif choice == "4":
                    await self._update_own_status()
                else:
                    console.print("[red]Invalid option[/red]")

            except (EOFError, KeyboardInterrupt):
                break

        await self.daemon._shutdown()

    async def _search_agents(self):
        """搜索协同资源"""
        console.print("\n[cyan]🔍 Searching for text cleaning agents...[/cyan]\n")

        matches = await self.daemon.search_collaborators(
            query="需要清洗文本数据，去除多余空格和格式化",
            domain="data"
        )

        if matches:
            from client_sdk.cli.prompts import match_prompt_rich
            selected_indices = await match_prompt_rich(matches)

            console.print(f"\n[dim]Selected: {selected_indices}[/dim]")
        else:
            console.print("[yellow]No matches found[/yellow]")

    async def _send_test_task(self):
        """发送测试任务给 Agent B"""
        console.print("\n[cyan]📤 Sending test task to Agent B...[/cyan]\n")

        # 模拟发送 P2P 任务
        # 实际场景中，这里会通过 P2PSender 发送
        test_payload = {
            "task_type": "clean_text",
            "task_context": {
                "text": "  Hello    World!   This  is  a  test.  " * 10
            }
        }

        console.print("[dim]Task Payload:[/dim]")
        console.print(f"  Type: {test_payload['task_type']}")
        console.print(f"  Text: {test_payload['task_context']['text'][:50]}...")

        # 在实际实现中，这里会通过 Webhook 发送
        # 为了测试，我们直接调用 Agent B 的处理器
        console.print("\n[yellow]Note: In production, this would be sent via P2P webhook[/yellow]")
        console.print("[dim]For testing, we'll simulate the P2P call...[/dim]\n")

    async def _check_agent_status(self):
        """检查 Agent B 状态"""
        console.print("\n[cyan]📊 Checking Agent B status...[/cyan]\n")

        # 在实际实现中，这里会调用 Hub API 获取 Agent 状态
        console.print("[dim]Agent Status (from Hub):[/dim]")
        console.print("  ID: text_cleaning_bot")
        console.print("  Node Status: [green]🟢 active[/green]")
        console.print("  Live Broadcast: [dim]Processing 10K files, ETA 5 min[/dim]")
        console.print("  Tasks Provided: 342")

    async def _update_own_status(self):
        """更新自己的状态"""
        console.print("\n[cyan]📡 Updating own status...[/cyan]\n")

        await self.daemon.update_status(
            node_status="busy",
            live_broadcast="Analyzing financial data, please wait..."
        )

        console.print("[green]✅ Status updated[/green]")
        console.print("  Node Status: [yellow]busy[/yellow]")
        console.print("  Live Broadcast: Analyzing financial data...")

        await asyncio.sleep(2)

        # 恢复为 active
        await self.daemon.update_status(
            node_status="active",
            live_broadcast="Ready for new tasks"
        )

        console.print("\n[green]✅ Status restored to active[/green]")


# ============================================================================
# Test Fixtures
# ============================================================================

def create_test_fixtures():
    """创建测试用的 identity.md 文件"""
    import os

    fixtures_dir = Path("tests/fixtures")
    fixtures_dir.mkdir(parents=True, exist_ok=True)

    # Agent A identity
    identity_a = fixtures_dir / "identity_agent_a.md"
    if not identity_a.exists():
        identity_a.write_text("""# Data Analysis Bot

【提供能力】：数据分析、可视化、报表生成

【寻求合作】：需要数据清洗服务
""")

    # Agent B identity
    identity_b = fixtures_dir / "identity_agent_b.md"
    if not identity_b.exists():
        identity_b.write_text("""# Text Cleaning Bot

【提供能力】：文本清洗、格式化、去重

【寻求合作】：需要高质量数据源
""")


# ============================================================================
# Main Test Runner
# ============================================================================

async def run_e2e_test():
    """
    运行端到端测试

    流程：
    1. 创建测试文件
    2. 启动 Agent B（后台）
    3. 启动 Agent A（交互）
    """
    from rich.panel import Panel

    # 显示欢迎信息
    welcome_panel = Panel(
        """[bold green]AgentHub V1.5 End-to-End Test[/bold green]

This test simulates two agents interacting:
  • [cyan]Agent A[/cyan] (Data Analysis) - Looking for text cleaning service
  • [cyan]Agent B[/cyan] (Text Cleaning) - Providing cleaning service

[c yellow]Make sure Hub server is running on http://localhost:8000[/c yellow]

Press Ctrl+C to exit at any time.""",
        title="[bold blue]Welcome[/bold blue]",
        border_style="blue"
    )
    console.print(welcome_panel)

    # 创建测试文件
    console.print("\n[dim]Creating test fixtures...[/dim]")
    create_test_fixtures()
    console.print("[green]✅ Test fixtures created[/green]\n")

    # 启动 Agent B（后台）
    agent_b = TextCleaningAgent()

    # 在后台运行 Agent B
    console.print("[cyan]Starting Agent B in background...[/cyan]")
    agent_b_task = asyncio.create_task(agent_b.start())

    # 等待 Agent B 启动
    await asyncio.sleep(2)

    # 启动 Agent A（前台交互）
    agent_a = DataAnalysisAgent()

    try:
        await agent_a.start()
    except KeyboardInterrupt:
        console.print("\n\n[yellow]Test interrupted by user[/yellow]")
    finally:
        # 清理
        console.print("\n[yellow]Shutting down agents...[/yellow]")
        agent_b_task.cancel()
        try:
            await agent_b_task
        except asyncio.CancelledError:
            pass

        console.print("[green]✅ Test completed[/green]")


# ============================================================================
# Direct Task Test (Simpler version)
# ============================================================================

async def test_direct_task():
    """
    简化版测试：直接测试任务处理

    不依赖 Hub 服务器，仅测试任务处理逻辑
    """
    from rich.panel import Panel

    console.print(Panel(
        "[bold green]Direct Task Test[/bold green]\n\n"
        "Testing Agent B's task processing without Hub",
        title="[bold blue]Test Mode[/bold blue]"
    ))

    agent_b = TextCleaningAgent()

    # 测试任务 1: clean_text
    console.print("\n[cyan]Test 1: clean_text[/cyan]")
    result1 = await agent_b.task_handler(
        "clean_text",
        {"text": "  Hello    World!   " * 10}
    )
    console.print(f"[dim]Result:[/dim] {result1}")

    # 测试任务 2: format_markdown
    console.print("\n[cyan]Test 2: format_markdown[/cyan]")
    result2 = await agent_b.task_handler(
        "format_markdown",
        {"text": "# Test Content\n\nSome text here"}
    )
    console.print(f"[dim]Result:[/dim] {result2}")

    # 测试任务 3: unknown
    console.print("\n[cyan]Test 3: unknown task[/cyan]")
    result3 = await agent_b.task_handler(
        "unknown_task",
        {}
    )
    console.print(f"[dim]Result:[/dim] {result3}")

    # 显示统计
    console.print(f"\n[bold]Total tasks received:[/bold] {len(agent_b.received_tasks)}")

    console.print("\n[green]✅ Direct task test completed[/green]")


# ============================================================================
# Entry Point
# ============================================================================

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="AgentHub V1.5 E2E Test")
    parser.add_argument(
        "--mode",
        choices=["full", "direct"],
        default="full",
        help="Test mode: 'full' (with Hub) or 'direct' (task processing only)"
    )

    args = parser.parse_args()

    if args.mode == "full":
        console.print("[yellow]Starting full E2E test (requires Hub server)[/yellow]\n")
        asyncio.run(run_e2e_test())
    else:
        console.print("[yellow]Starting direct task test (no Hub required)[/yellow]\n")
        asyncio.run(test_direct_task())
