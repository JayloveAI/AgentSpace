﻿import sys
from pathlib import Path


sys.path.insert(0, str(Path(__file__).parent.parent))

from client_sdk.daemon.gateway import LocalGatewayDaemon
from client_sdk.webhook import server as webhook_server


def test_gateway_instance_is_set():
    dummy_gateway = object()
    LocalGatewayDaemon(agent_id="agent-test", gateway_instance=dummy_gateway)

    assert webhook_server._gateway_instance is dummy_gateway
